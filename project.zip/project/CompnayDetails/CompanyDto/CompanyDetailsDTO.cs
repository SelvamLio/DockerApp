﻿using System.ComponentModel.DataAnnotations;

namespace CompnayDetails.CompanyDto
{
    public class CompanyDetailsDTO
    {
        [Required]
        public string CompanyCode { get; set; }
        [Required]
        public string CompanyName { get; set; }
        [Required]
        public string CompanyCeo { get; set; }
        [Required]
        public decimal Turnover { get; set; }
        [Required]
        public string Website { get; set; }
        [Required]
        public string StockExchange { get; set; }
        public int StockExchangeID { get; set; }
    }
}
