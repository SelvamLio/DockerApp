﻿namespace CompnayDetails.CompanyDto
{
    public class StockExchangeDTO
    {
        public string StockName { get; set; }
        public int StockID { get; set; }
    }
}
