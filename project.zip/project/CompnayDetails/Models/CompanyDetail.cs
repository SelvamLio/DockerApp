﻿using System.ComponentModel.DataAnnotations;

namespace CompnayDetails.Models
{
    public partial class CompanyDetail
    {        
        public int CompanyId { get; set; }
        [Required]
        public string CompanyCode { get; set; }
        [Required]
        public string CompanyName { get; set; }
        [Required]
        public string CompanyCeo { get; set; }
        [Required]
        public decimal Turnover { get; set; }
        [Required]
        public string Website { get; set; }
        [Required]
        public int? StockExchange { get; set; }

        public virtual StockExchange StockExchangeNavigation { get; set; }
    }
}
