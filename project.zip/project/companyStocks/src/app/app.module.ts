import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { CompanyAddComponent } from './company-add/company-add.component';
import { CompanyService } from './service/company.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { StockListComponent } from './stock-list/stock-list.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';
import { StockService } from './service/stock.service';
import { MaxPipe } from './Pipe/MaxPipe.Pipe';
import { MinPipe } from './Pipe/MinPipe.pipe';
import { AvgPipe } from './Pipe/AvgPipe.Pipe';
import { Ng2SearchPipe, Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [
    AppComponent,
    CompanyDetailsComponent,
    CompanyAddComponent,
    StockListComponent,
    MinPipe,
    MaxPipe,
    AvgPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,    
    ReactiveFormsModule,
    HttpClientModule,
    BsDatepickerModule.forRoot(),
    BrowserAnimationsModule, 
    Ng2SearchPipeModule
  ],
  providers: [
    CompanyService,
    StockService,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
